

CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `aksi` varchar(255) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `waktu` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `modul` varchar(255) DEFAULT NULL,
  `lokasi` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `audit_logs` VALUES ('1','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:25:49','2026-05-01 18:25:49','2026-05-01 18:25:49',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('2','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:26:23','2026-05-01 18:26:23','2026-05-01 18:26:23',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('3','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:27:35','2026-05-01 18:27:35','2026-05-01 18:27:35',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('4','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:32:42','2026-05-01 18:32:42','2026-05-01 18:32:42',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('5','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:32:57','2026-05-01 18:32:57','2026-05-01 18:32:57',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('6','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:34:04','2026-05-01 18:34:04','2026-05-01 18:34:04',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('7','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:36:05','2026-05-01 18:36:05','2026-05-01 18:36:05',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('8','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:38:29','2026-05-01 18:38:29','2026-05-01 18:38:29',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('9','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:39:57','2026-05-01 18:39:57','2026-05-01 18:39:57',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('10','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 18:47:37','2026-05-01 18:47:37','2026-05-01 18:47:37',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('11','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 19:26:14','2026-05-01 19:26:14','2026-05-01 19:26:14',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('12','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-01 19:26:23','2026-05-01 19:26:23','2026-05-01 19:26:23',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('13','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1','2026-05-01 19:27:46','2026-05-01 19:27:46','2026-05-01 19:27:46',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('14','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1','2026-05-01 19:27:56','2026-05-01 19:27:56','2026-05-01 19:27:56',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('15','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1','2026-05-01 19:28:32','2026-05-01 19:28:32','2026-05-01 19:28:32',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('16','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1','2026-05-02 14:53:34','2026-05-02 14:53:34','2026-05-02 14:53:34',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('17','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1','2026-05-02 14:54:13','2026-05-02 14:54:13','2026-05-02 14:54:13',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('18','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1','2026-05-02 14:54:20','2026-05-02 14:54:20','2026-05-02 14:54:20',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('19','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1','2026-05-02 14:54:24','2026-05-02 14:54:24','2026-05-02 14:54:24',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('20','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 14:56:04','2026-05-02 14:56:04','2026-05-02 14:56:04',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('21','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 14:59:47','2026-05-02 14:59:47','2026-05-02 14:59:47',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('22','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 14:59:53','2026-05-02 14:59:53','2026-05-02 14:59:53',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('23',NULL,NULL,'admin@gmail.com',NULL,'LOGIN_GAGAL','Percobaan login gagal untuk email: admin@gmail.com','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 15:01:46','2026-05-02 15:01:46','2026-05-02 15:01:46',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('24','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 15:16:08','2026-05-02 15:16:08','2026-05-02 15:16:08',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('25','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 17:19:54','2026-05-02 17:19:54','2026-05-02 17:19:54',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('26','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 17:20:12','2026-05-02 17:20:12','2026-05-02 17:20:12',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('27','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 20:22:51','2026-05-02 20:22:51','2026-05-02 20:22:51',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('28','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 20:23:11','2026-05-02 20:23:11','2026-05-02 20:23:11',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('29','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 20:23:18','2026-05-02 20:23:18','2026-05-02 20:23:18',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('30','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-02 20:37:23','2026-05-02 20:37:23','2026-05-02 20:37:23',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('31','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-03 00:31:20','2026-05-03 00:31:20','2026-05-03 00:31:20',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('32','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-03 00:31:54','2026-05-03 00:31:54','2026-05-03 00:31:54',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('33','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-03 00:32:00','2026-05-03 00:32:00','2026-05-03 00:32:00',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('34','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-03 00:32:03','2026-05-03 00:32:03','2026-05-03 00:32:03',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('35','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-03 00:34:06','2026-05-03 00:34:06','2026-05-03 00:34:06',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('36','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-03 00:38:39','2026-05-03 00:38:39','2026-05-03 00:38:39',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('37','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-03 00:44:31','2026-05-03 00:44:31','2026-05-03 00:44:31',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('38','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-03 00:44:36','2026-05-03 00:44:36','2026-05-03 00:44:36',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('39','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-03 00:44:40','2026-05-03 00:44:40','2026-05-03 00:44:40',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('40','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-03 00:44:44','2026-05-03 00:44:44','2026-05-03 00:44:44',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('41','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-03 00:51:51','2026-05-03 00:51:51','2026-05-03 00:51:51',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('42','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-03 00:51:54','2026-05-03 00:51:54','2026-05-03 00:51:54',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('43','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-03 00:51:57','2026-05-03 00:51:57','2026-05-03 00:51:57',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('44','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-03 00:52:01','2026-05-03 00:52:01','2026-05-03 00:52:01',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('45','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-03 00:56:32','2026-05-03 00:56:32','2026-05-03 00:56:32',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('46','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','10.126.74.80','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','2026-05-03 00:58:49','2026-05-03 00:58:49','2026-05-03 00:58:49',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('47','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-03 19:20:43','2026-05-03 19:20:43','2026-05-03 19:20:43',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('48','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-04 14:00:29','2026-05-04 14:00:29','2026-05-04 14:00:29',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('49','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-04 14:00:34','2026-05-04 14:00:34','2026-05-04 14:00:34',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('50','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-04 14:00:38','2026-05-04 14:00:38','2026-05-04 14:00:38',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('51','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-04 14:02:03','2026-05-04 14:02:03','2026-05-04 14:02:03',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('52','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','125.165.104.116','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-04 14:15:18','2026-05-04 14:15:18','2026-05-04 14:15:18',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('53','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','125.165.108.76','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1','2026-05-04 14:43:08','2026-05-04 14:43:08','2026-05-04 14:43:08',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('54','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','112.215.236.97','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','2026-05-04 15:04:46','2026-05-04 15:04:46','2026-05-04 15:04:46',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('55','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','125.165.105.112','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36','2026-05-04 15:22:36','2026-05-04 15:22:36','2026-05-04 15:22:36',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('56','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','125.165.105.112','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36','2026-05-04 16:01:17','2026-05-04 16:01:17','2026-05-04 16:01:17',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('57','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','125.165.105.112','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36','2026-05-04 16:01:42','2026-05-04 16:01:42','2026-05-04 16:01:42',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('58','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.150.71','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','2026-05-04 16:06:17','2026-05-04 16:06:17','2026-05-04 16:06:17',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('59','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','103.129.150.71','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','2026-05-04 16:09:49','2026-05-04 16:09:49','2026-05-04 16:09:49',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('60','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-04 16:54:09','2026-05-04 16:54:09','2026-05-04 16:54:09',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('61','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-04 16:55:02','2026-05-04 16:55:02','2026-05-04 16:55:02',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('62','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-04 17:00:10','2026-05-04 17:00:10','2026-05-04 17:00:10',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('63','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.21','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','2026-05-04 17:02:56','2026-05-04 17:02:56','2026-05-04 17:02:56',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('64','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.21','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147 Version/11.1.1 Safari/605.1.15','2026-05-04 17:14:12','2026-05-04 17:14:12','2026-05-04 17:14:12',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('65','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 01:10:20','2026-05-05 01:10:20','2026-05-05 01:10:20',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('66','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 01:10:29','2026-05-05 01:10:29','2026-05-05 01:10:29',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('67','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 01:10:52','2026-05-05 01:10:52','2026-05-05 01:10:52',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('68','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.241','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 01:10:57','2026-05-05 01:10:57','2026-05-05 01:10:57',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('69','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','114.125.62.99','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','2026-05-05 11:45:56','2026-05-05 11:45:56','2026-05-05 11:45:56',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('70','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','114.125.62.99','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','2026-05-05 11:46:43','2026-05-05 11:46:43','2026-05-05 11:46:43',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('71','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','114.125.60.239','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','2026-05-05 11:49:16','2026-05-05 11:49:16','2026-05-05 11:49:16',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('72','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','114.125.47.111','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','2026-05-05 12:09:33','2026-05-05 12:09:33','2026-05-05 12:09:33',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('73','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','114.125.47.111','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','2026-05-05 12:09:54','2026-05-05 12:09:54','2026-05-05 12:09:54',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('74','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:22:23','2026-05-05 17:22:23','2026-05-05 17:22:23',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('75','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:22:59','2026-05-05 17:22:59','2026-05-05 17:22:59',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('76','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:23:07','2026-05-05 17:23:07','2026-05-05 17:23:07',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('77','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:23:43','2026-05-05 17:23:43','2026-05-05 17:23:43',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('78','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:24:01','2026-05-05 17:24:01','2026-05-05 17:24:01',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('79','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:24:56','2026-05-05 17:24:56','2026-05-05 17:24:56',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('80','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:38:10','2026-05-05 17:38:10','2026-05-05 17:38:10',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('81','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:48:34','2026-05-05 17:48:34','2026-05-05 17:48:34',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('82','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:48:41','2026-05-05 17:48:41','2026-05-05 17:48:41',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('83','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:49:06','2026-05-05 17:49:06','2026-05-05 17:49:06',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('84','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:49:32','2026-05-05 17:49:32','2026-05-05 17:49:32',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('85','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','HAPUS_BACKUP','Hapus backup: backup-2026-05-02-08-48-31.zip','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:52:37','2026-05-05 17:52:37','2026-05-05 17:52:37',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('86','1','Ikhsan Fitrah Al Mubarak','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:52:43','2026-05-05 17:52:43','2026-05-05 17:52:43',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('87','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 17:54:32','2026-05-05 17:54:32','2026-05-05 17:54:32',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('88','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','180.248.111.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-05 20:21:24','2026-05-05 20:21:24','2026-05-05 20:21:24',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('89','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 10:53:36','2026-05-06 10:53:36','2026-05-06 10:53:36',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('90','1','IkhsanFitrah','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:06:33','2026-05-06 11:06:33','2026-05-06 11:06:33',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('91','1','IkhsanFitrah','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:11:40','2026-05-06 11:11:40','2026-05-06 11:11:40',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('92','1','IkhsanFitrah','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:20:47','2026-05-06 11:20:47','2026-05-06 11:20:47',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('93','1','IkhsanFitrah','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:23:16','2026-05-06 11:23:16','2026-05-06 11:23:16',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('94','1','IkhsanFitrah','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:30:43','2026-05-06 11:30:43','2026-05-06 11:30:43',NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('95','1','IkhsanFitrah','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:43:19',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('96','1','IkhsanFitrah','owner@bengkel.com','owner','BACKUP','Backup database berhasil dibuat','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:48:28',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('97','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:52:51',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('98','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:53:00',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('99','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:58:10',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('100','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:58:37',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('101','1','IkhsanFitrah','owner@bengkel.com','owner','HAPUS_BACKUP','Hapus backup: backup_2026-05-06_11-43-19.zip','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:58:58',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('102','1','IkhsanFitrah','owner@bengkel.com','owner','HAPUS_BACKUP','Hapus backup: backup_2026-05-06_11-30-43.zip','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 11:59:04',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('103','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 12:01:06',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('104','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.251','Mozilla/5.0 (Linux; Android 16; SM-G980F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.260 Mobile Safari/537.36','2026-05-06 12:26:06',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('105','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 12:26:49',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('106','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-06 12:32:38',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('107','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.160','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-07 17:32:17',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('108','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.160','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-07 17:33:10',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('109','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.100','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-08 17:43:18',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('110','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.100','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-08 17:45:07',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('111','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.100','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-08 17:45:25',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('112','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.100','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-08 17:50:55',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('113','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-09 00:30:36',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('114','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-09 00:30:46',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('115','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.158','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-09 00:41:38',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('116','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.158','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-09 00:42:03',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('117','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.150.103','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-09 23:12:48',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('118','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.205','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-10 01:20:59',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('119','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.205','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-10 01:21:53',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('120','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.205','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-10 01:22:03',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('121','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.205','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-10 01:23:24',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('122',NULL,NULL,'owner@bengkel.com',NULL,'LOGIN_GAGAL','Percobaan login gagal untuk email: owner@bengkel.com','110.138.182.39','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.15','2026-05-10 16:24:25',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('123','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.39','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.15','2026-05-10 16:24:56',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('124','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.88','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.15','2026-05-10 22:54:27',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('125','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.88','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.15','2026-05-10 22:55:18',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('126','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.88','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.15','2026-05-10 22:55:50',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('127','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.88','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.15','2026-05-10 22:57:31',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('128','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','125.165.111.244','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-11 02:19:20',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('129','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.150.103','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-11 16:28:30',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('130','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','103.129.150.103','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-11 16:29:10',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('131','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','103.129.150.103','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-11 16:29:16',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('132','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','103.129.150.103','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-11 16:59:49',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('133','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.203','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-11 23:08:46',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('134','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.203','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-11 23:13:30',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('135','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.203','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-11 23:14:29',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('136','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.203','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-11 23:14:57',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('137','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.203','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','2026-05-11 23:22:24',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('138','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','114.125.11.98','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-12 11:10:31',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('139','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','114.125.24.209','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-12 11:11:07',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('140','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','182.1.18.216','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','2026-05-12 11:59:37',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('141','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.150.103','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1','2026-05-12 17:41:16',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('142','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','114.125.31.83','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-22 14:56:38',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('143','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','114.125.29.129','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-22 14:57:29',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('144','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','114.125.29.129','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-22 14:58:53',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('145','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.150.77','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-24 15:01:52',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('146','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.5','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-28 16:49:30',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('147','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 17:19:29',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('148','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.5','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-28 17:42:44',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('149','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.5','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-28 17:42:50',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `audit_logs` VALUES ('150','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.5','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-28 18:06:49',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('151','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.5','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-28 18:07:24',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('152','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 18:07:39',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('153','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 18:07:43',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('154','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.5','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.166 Mobile/15E148 Safari/604.1','2026-05-28 18:07:49',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('155','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 18:09:02',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('156','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-05-28 19:10:44',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('157',NULL,NULL,'owner@gmail.com',NULL,'LOGIN_GAGAL','Percobaan login gagal untuk email: owner@gmail.com','110.138.182.96','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 07:39:27',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('158','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.96','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 07:39:35',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('159','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.96','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 07:39:47',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('160','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.96','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 07:39:58',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('161','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.96','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 07:41:18',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('162','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','156.230.182.13','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-07 15:57:47',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('163','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','156.230.182.13','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-07 15:58:26',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('164','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','203.83.45.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-07 16:53:04',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('165','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','203.83.45.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-07 16:53:51',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('166',NULL,NULL,'isan@bengkel.com',NULL,'LOGIN_GAGAL','Percobaan login gagal untuk email: isan@bengkel.com','156.230.182.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-07 17:03:47',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('167','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','156.230.182.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','2026-06-07 17:04:00',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('168','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','156.230.182.49','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 17:05:48',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('169','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','156.230.182.49','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 17:06:34',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('170',NULL,NULL,'onbold@gmail.com',NULL,'LOGIN_GAGAL','Percobaan login gagal untuk email: onbold@gmail.com','156.230.182.49','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 17:07:05',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('171',NULL,NULL,'anomali@gmail.com',NULL,'LOGIN_GAGAL','Percobaan login gagal untuk email: anomali@gmail.com','156.230.182.49','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 17:07:38',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('172','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','156.230.182.49','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-07 17:09:03',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('173','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','182.1.32.119','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/149.0.7827.45 Mobile/15E148 Safari/604.1','2026-06-07 22:23:55',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('174',NULL,NULL,'owner@gmail.com',NULL,'LOGIN_GAGAL','Percobaan login gagal untuk email: owner@gmail.com','103.129.26.2','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-08 22:10:07',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('175','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.26.2','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-08 22:10:31',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('176','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','103.129.26.2','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-08 22:40:31',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('177','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','103.129.26.2','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-08 22:40:55',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('178','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','103.129.26.2','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-08 22:54:47',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('179','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.26.2','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-08 23:04:33',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('180','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','103.129.26.2','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-08 23:05:27',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('181','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','103.129.26.2','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-08 23:05:54',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('182','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','203.83.45.38','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-15 20:06:36',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('183','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','203.83.45.39','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-06-15 20:07:20',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('184','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.208','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/149.0.7827.137 Mobile/15E148 Safari/604.1','2026-07-01 00:25:47',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('185','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.26.55','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','2026-07-02 23:30:17',NULL,NULL,'AUTH','Indonesia','Microsoft Edge','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('186','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.150.76','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-07-04 13:01:18',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('187','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.150.76','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-07-05 21:24:09',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('188','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','182.1.3.113','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-07-06 20:00:10',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('189','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','114.125.12.38','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','2026-07-06 20:01:37',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('190','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.150.95','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-17 18:02:13',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('191','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','103.129.150.95','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-17 18:03:17',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('192','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','103.129.150.95','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-17 20:38:17',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('193','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.71','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-23 02:00:54',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('194','1','IkhsanFitrah','owner@bengkel.com','owner','LOGOUT','Keluar dari sistem','110.138.182.71','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-23 02:01:50',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('195','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.71','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-23 02:01:59',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('196','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.71','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-23 02:02:35',NULL,NULL,'AUTH','Indonesia','Safari','iOS');
INSERT INTO `audit_logs` VALUES ('197','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-24 23:16:00',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('198','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-24 23:16:25',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('199','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-24 23:16:50',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('200','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-24 23:24:36',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('201','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-24 23:24:49',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('202','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-24 23:25:29',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('203','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-24 23:25:35',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('204','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','110.138.182.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-24 23:35:41',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('205','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','110.138.182.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-24 23:35:59',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('206','2','Afif Al Azhar','admin@bengkel.com','admin','LOGIN','Berhasil login ke sistem','103.129.150.69','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-25 19:06:03',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('207','2','Afif Al Azhar','admin@bengkel.com','admin','LOGOUT','Keluar dari sistem','103.129.150.69','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-25 19:23:50',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');
INSERT INTO `audit_logs` VALUES ('208','1','IkhsanFitrah','owner@bengkel.com','owner','LOGIN','Berhasil login ke sistem','110.138.182.229','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-26 00:05:10',NULL,NULL,'AUTH','Indonesia','Google Chrome','Windows 10/11');


CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `kendaraans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pelanggan_id` bigint(20) unsigned NOT NULL,
  `merk` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `tahun` varchar(4) DEFAULT NULL,
  `plat_nomor` varchar(255) NOT NULL,
  `warna` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kendaraans_plat_nomor_unique` (`plat_nomor`),
  KEY `kendaraans_pelanggan_id_foreign` (`pelanggan_id`),
  CONSTRAINT `kendaraans_pelanggan_id_foreign` FOREIGN KEY (`pelanggan_id`) REFERENCES `pelanggans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `kendaraans` VALUES ('1','1','Yamaha','X-MAX','2021','B  805 WAN','Hitam','2026-04-29 17:44:45','2026-04-30 02:09:15');
INSERT INTO `kendaraans` VALUES ('2','2','Honda','Vario 160','2022','B  1305 L','Putih','2026-04-30 19:09:53','2026-04-30 19:09:53');
INSERT INTO `kendaraans` VALUES ('3','3','Kawasaki','Ninja','2021','BM 1 G','Kuning','2026-04-30 20:34:06','2026-04-30 20:34:06');
INSERT INTO `kendaraans` VALUES ('4','4','Sumitomo','crawler crane 7035','2006','BM 789 NV','kuning','2026-05-04 15:48:19','2026-05-04 15:48:19');
INSERT INTO `kendaraans` VALUES ('5','5','Kawasaki','wsr 175','2018','BM 3288 TL','silver','2026-05-04 16:04:09','2026-05-04 16:04:09');


CREATE TABLE `mekaniks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `telepon` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `mekaniks` VALUES ('1','Muhammad Marfin','085232123456','JL Arifin Ahmad','aktif','2026-04-29 12:53:58','2026-04-29 12:53:58');
INSERT INTO `mekaniks` VALUES ('2','Ghani Attalahh','112233445566','Jl. T bey','aktif','2026-04-30 20:01:54','2026-05-04 14:43:52');
INSERT INTO `mekaniks` VALUES ('3','suci anggela','0822','TERUBUK','aktif','2026-05-04 14:44:13','2026-05-04 14:44:13');


CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES ('1','2026_04_29_114836_create_users_table','1');
INSERT INTO `migrations` VALUES ('2','2026_04_29_115256_create_sessions_table','1');
INSERT INTO `migrations` VALUES ('3','2026_04_29_154355_create_layanan_table','2');
INSERT INTO `migrations` VALUES ('4','2026_04_30_020024_create_mekaniks_table','3');
INSERT INTO `migrations` VALUES ('5','2026_04_30_020042_create_pelanggans_table','3');
INSERT INTO `migrations` VALUES ('6','2026_04_30_020051_create_kendaraans_table','3');
INSERT INTO `migrations` VALUES ('7','2026_04_30_020112_create_servis_table','3');
INSERT INTO `migrations` VALUES ('8','2026_04_30_020131_create_spare_parts_table','3');
INSERT INTO `migrations` VALUES ('9','2026_04_30_020147_create_transaksis_table','3');
INSERT INTO `migrations` VALUES ('10','2026_04_30_020150_create_transaksi_details_table','3');
INSERT INTO `migrations` VALUES ('11','2026_05_01_073513_create_cache_table','4');
INSERT INTO `migrations` VALUES ('12','2026_05_02_074045_create_audit_logs_table','5');


CREATE TABLE `pelanggans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `telepon` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pelanggans` VALUES ('1','Ridwan Rasyid','0987654321','ridwan@gmail.com','Jl. Harapan Raya','2026-04-29 17:12:50','2026-04-30 02:08:41');
INSERT INTO `pelanggans` VALUES ('2','Louis','0102030405','louis@gmail.com','Jl. Pekalogan','2026-04-30 19:08:48','2026-04-30 19:08:48');
INSERT INTO `pelanggans` VALUES ('3','Ghazi','1123445678','Ghazi@gmail.com','Jl. Utama','2026-04-30 20:33:05','2026-04-30 20:33:05');
INSERT INTO `pelanggans` VALUES ('4','jondoe','22233344555','jondoe@ss.com','jl.dancok','2026-05-04 15:41:32','2026-05-04 15:41:32');
INSERT INTO `pelanggans` VALUES ('5','Djarum','556644','djarum1@gmail.con','jl. Al il ul','2026-05-04 16:03:17','2026-06-07 17:10:17');


CREATE TABLE `servis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `no_order` varchar(255) NOT NULL,
  `pelanggan_id` bigint(20) unsigned NOT NULL,
  `kendaraan_id` bigint(20) unsigned NOT NULL,
  `mekanik_id` bigint(20) unsigned NOT NULL,
  `keluhan` text NOT NULL,
  `diagnosa` text DEFAULT NULL,
  `status` enum('antrian','proses','selesai','batal') NOT NULL DEFAULT 'antrian',
  `biaya_jasa` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tanggal_masuk` date NOT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `servis_no_order_unique` (`no_order`),
  KEY `servis_pelanggan_id_foreign` (`pelanggan_id`),
  KEY `servis_kendaraan_id_foreign` (`kendaraan_id`),
  KEY `servis_mekanik_id_foreign` (`mekanik_id`),
  CONSTRAINT `servis_kendaraan_id_foreign` FOREIGN KEY (`kendaraan_id`) REFERENCES `kendaraans` (`id`),
  CONSTRAINT `servis_mekanik_id_foreign` FOREIGN KEY (`mekanik_id`) REFERENCES `mekaniks` (`id`),
  CONSTRAINT `servis_pelanggan_id_foreign` FOREIGN KEY (`pelanggan_id`) REFERENCES `pelanggans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `servis` VALUES ('1','SRV-0001','1','1','1','Ganti oli',NULL,'selesai','75000.00','2026-04-30',NULL,NULL,'2026-04-29 20:04:35','2026-04-29 20:04:35');
INSERT INTO `servis` VALUES ('2','SRV-0002','2','2','2','Ganti Oli',NULL,'selesai','75000.00','2026-05-01','2026-05-01',NULL,'2026-04-30 20:03:10','2026-04-30 20:27:28');
INSERT INTO `servis` VALUES ('3','SRV-0003','3','3','2','Ganti Oli',NULL,'selesai','25000.00','2026-05-01',NULL,NULL,'2026-04-30 20:35:46','2026-04-30 20:35:46');
INSERT INTO `servis` VALUES ('4','SRV-0004','4','4','1','bunyi ngik ngik, dan bocor hose hidrolik','oli kurang','selesai','2000000.00','2026-05-04',NULL,'kasbon dulu','2026-05-04 15:50:01','2026-05-04 15:54:50');
INSERT INTO `servis` VALUES ('5','SRV-0005','5','5','2','ganti oli','servis rutin','selesai','120000.00','2026-05-04',NULL,NULL,'2026-05-04 16:05:06','2026-05-04 16:05:30');
INSERT INTO `servis` VALUES ('6','SRV-0006','4','4','1','nmnm','nmnm','proses','99996.00','2026-06-08',NULL,NULL,'2026-06-08 23:10:39','2026-07-26 00:12:52');


CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sessions` VALUES ('3bn2LBGdLJUBnlonYqvB3BojrYU4fO49UdB5OURd',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZloycjVTNFpSSlpKRHBRSmJoeVJGZXF6djh4SGxGUjdYM2h2dEdVRCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=','1777814473');
INSERT INTO `sessions` VALUES ('3cPQIoYAY57OZS9Fq9tkQzjQNZDuzOGNJEKhfhml',NULL,'127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYzBWV2dSQzFaMnFDNklEa2ppbUZQS0RMbWx2amx2WDlBdzdCSzNyRiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMCI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==','1777814547');
INSERT INTO `sessions` VALUES ('5hgYlCRlneCP7kl8YGGtULExradtwYprlG5PRHbD',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZXFSanFlS25rQ01nT3poUWlaZ012emFXTms5WktoZ0tVM3BkSnozaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=','1777813131');
INSERT INTO `sessions` VALUES ('7nbjVyf6w953fyF6BunxZQYzedcIQkC8YYu1eytd',NULL,'10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOTV2bEljQk9wTmtxUVdWeXZZdk1qRXR1Z0JVUzZJaEpzd2JpTktUVCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8xMC4xMjYuMTYyLjEwOTo4MDAwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9fQ==','1777820192');
INSERT INTO `sessions` VALUES ('a7Ivip3JS4q8Srfp4yudG0SVQBmrgQjAT81ZmVhK',NULL,'127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUmR0RXp6ZjRGVHZTV3hQNnJaNng4V1ZDN05wd3VMQnNIT2Jad210TiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMCI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==','1777814258');
INSERT INTO `sessions` VALUES ('aftV7H5dYuGZMs44SU57fId6tgT7UMML0RBM195m','2','10.126.74.80','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','YTo0OntzOjY6Il90b2tlbiI7czo0MDoib2ZvbGZOM1Y3R3g4QkhtbHFnYkJ1OUlGNG1TMWNhVHFqaUFINVlOUiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDI6Imh0dHA6Ly8xMC4xMjYuMTYyLjEwOTo4MDAwL2FkbWluL2Rhc2hib2FyZCI7czo1OiJyb3V0ZSI7czoxNToiYWRtaW4uZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjt9','1777820329');
INSERT INTO `sessions` VALUES ('eQRncKP9PTgSxx2oPP6mj0NICmcv9G3VbdFFN1fk','1','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiTWlsclEydlllM1V6T2RPWHByb1RoSXU1TGx6OHpkeUZLWDZsVDR4diI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9vd25lci9hdWRpdC1sb2ciO3M6NToicm91dGUiO3M6MjE6Im93bmVyLmF1ZGl0LWxvZy5pbmRleCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==','1777820340');
INSERT INTO `sessions` VALUES ('fiwW86tQas75YpuqMFqWQWKo0vaJZPVvxwnKsQhZ','1','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoibktweFlqcDB0blAweHMwZzJmVjZOdjg4MDlMYzM1eWlKaEMxNDVpQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9vd25lci90cmFuc2Frc2kiO3M6NToicm91dGUiO3M6MjE6Im93bmVyLnRyYW5zYWtzaS5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==','1777886633');
INSERT INTO `sessions` VALUES ('HMxvOkjGR5aDXEUZaxOCpHDWFImXUkZzT58DSf4A','2','10.126.58.218','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNTUzeG9HSEpCYWFVUGVGVUVvOTRTZ1FSY2hTUmgxeEV3ZDJlTHhscSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDI6Imh0dHA6Ly8xMC4xMjYuMTYyLjEwOTo4MDAwL2FkbWluL2Rhc2hib2FyZCI7czo1OiJyb3V0ZSI7czoxNToiYWRtaW4uZGFzaGJvYXJkIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjt9','1777818724');
INSERT INTO `sessions` VALUES ('phHXbKlsqpfDhkh90QHfWCGxufp1DrzAdTlGltj9',NULL,'127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnZRYmlEdTNQSVA3SW52YlJ2cW9BV2VRN25yN2FNR1RNT1lTR2JYdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDg6Imh0dHA6Ly81NGFjLTExMC0xMzgtMTgyLTExOC5uZ3Jvay1mcmVlLmFwcC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=','1777813742');
INSERT INTO `sessions` VALUES ('RISyejqVklspI8v840p2QDUEFxhmjPSfMPHpv5g5',NULL,'127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/147.0.7727.99 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFVZZzhyM1RmTnNYWm15S1VUaFdKM09QcGhtZWlGcnQ5SW9jd1ZpMSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMCI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==','1777814346');
INSERT INTO `sessions` VALUES ('S1kHgFR8IQbHuJwYaFjz3Hp0TwhaVNS6d02OoUxs','1','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVjVpRGFIa1RQRjJPMlZoUmE5NVJ2SzRUZ3JEb1ZCb3hISGt6M3Z1bSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9vd25lci9hdWRpdC1sb2ciO3M6NToicm91dGUiO3M6MjE6Im93bmVyLmF1ZGl0LWxvZy5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==','1777818728');


CREATE TABLE `spare_parts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `kode` varchar(255) NOT NULL,
  `kategori` varchar(255) DEFAULT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `stok_minimum` int(11) NOT NULL DEFAULT 5,
  `harga_beli` decimal(12,2) NOT NULL DEFAULT 0.00,
  `harga_jual` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `spare_parts_kode_unique` (`kode`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `spare_parts` VALUES ('1','Oli Shell Helix HX7','SP-001','Pelumas','3','5','50000.00','75000.00','2026-04-29 17:35:08','2026-05-04 15:55:41');


CREATE TABLE `transaksi_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaksi_id` bigint(20) unsigned NOT NULL,
  `spare_part_id` bigint(20) unsigned NOT NULL,
  `qty` int(11) NOT NULL,
  `harga_satuan` decimal(12,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaksi_details_transaksi_id_foreign` (`transaksi_id`),
  KEY `transaksi_details_spare_part_id_foreign` (`spare_part_id`),
  CONSTRAINT `transaksi_details_spare_part_id_foreign` FOREIGN KEY (`spare_part_id`) REFERENCES `spare_parts` (`id`),
  CONSTRAINT `transaksi_details_transaksi_id_foreign` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksis` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `transaksi_details` VALUES ('1','1','1','1','75000.00','75000.00','2026-04-29 20:05:36','2026-04-29 20:05:36');
INSERT INTO `transaksi_details` VALUES ('2','2','1','1','75000.00','75000.00','2026-04-30 20:28:26','2026-04-30 20:28:26');
INSERT INTO `transaksi_details` VALUES ('3','3','1','3','75000.00','225000.00','2026-04-30 20:36:51','2026-04-30 20:36:51');
INSERT INTO `transaksi_details` VALUES ('4','4','1','2','75000.00','150000.00','2026-05-04 15:55:41','2026-05-04 15:55:41');


CREATE TABLE `transaksis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `no_transaksi` varchar(255) NOT NULL,
  `servis_id` bigint(20) unsigned NOT NULL,
  `total_jasa` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_parts` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_bayar` decimal(12,2) NOT NULL DEFAULT 0.00,
  `bayar` decimal(12,2) NOT NULL DEFAULT 0.00,
  `kembalian` decimal(12,2) NOT NULL DEFAULT 0.00,
  `metode_bayar` enum('tunai','transfer','qris') NOT NULL DEFAULT 'tunai',
  `status` enum('lunas','belum_lunas') NOT NULL DEFAULT 'belum_lunas',
  `tanggal_bayar` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaksis_no_transaksi_unique` (`no_transaksi`),
  KEY `transaksis_servis_id_foreign` (`servis_id`),
  CONSTRAINT `transaksis_servis_id_foreign` FOREIGN KEY (`servis_id`) REFERENCES `servis` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `transaksis` VALUES ('1','TRX-0001','1','75000.00','75000.00','150000.00','150000.00','0.00','tunai','lunas','2026-04-29 20:05:36','2026-04-29 20:05:36','2026-04-29 20:05:36');
INSERT INTO `transaksis` VALUES ('2','TRX-0002','2','75000.00','75000.00','150000.00','200000.00','50000.00','transfer','lunas','2026-04-30 20:28:26','2026-04-30 20:28:26','2026-04-30 20:28:26');
INSERT INTO `transaksis` VALUES ('3','TRX-0003','3','25000.00','225000.00','250000.00','274998.00','24998.00','qris','lunas','2026-04-30 20:36:51','2026-04-30 20:36:51','2026-04-30 20:36:51');
INSERT INTO `transaksis` VALUES ('4','TRX-0004','4','2000000.00','150000.00','2150000.00','0.00','0.00','transfer','lunas','2026-05-04 15:55:41','2026-05-04 15:55:41','2026-05-04 15:55:41');
INSERT INTO `transaksis` VALUES ('5','TRX-0005','5','120000.00','0.00','120000.00','150000.00','30000.00','tunai','lunas','2026-05-04 16:06:05','2026-05-04 16:06:05','2026-05-04 16:06:05');


CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('owner','admin') NOT NULL DEFAULT 'admin',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES ('1','IkhsanFitrah','owner@bengkel.com','$2y$12$f4qGicQVhBuhXT5TPHcih.rPnOz6p/T/XV2h7mgxDQIlKSDdoGkHu','owner','2026-04-28 22:17:33','2026-05-05 17:53:20');
INSERT INTO `users` VALUES ('2','Afif Al Azhar','admin@bengkel.com','$2y$12$zXPJq3NpzGJq/7F00TUzs.SEjxjwBKe3ttVKNptwA9MXUnGR11Xk2','admin','2026-04-28 22:17:33','2026-04-28 22:17:33');
